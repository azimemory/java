package skillup.day03.libraray.run;

import skillup.day03.libraray.view.LibraryMenu;

public class Run {

	public static void main(String[] args) {
		new LibraryMenu().mainMenu();
	}

}
